"""Bridge types registry."""
