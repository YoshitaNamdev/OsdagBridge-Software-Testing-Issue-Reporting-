"""truss module."""
