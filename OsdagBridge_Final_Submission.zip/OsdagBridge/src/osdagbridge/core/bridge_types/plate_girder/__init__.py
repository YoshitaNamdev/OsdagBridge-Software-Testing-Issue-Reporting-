"""plate_girder module."""
